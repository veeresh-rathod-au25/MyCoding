1) n+n+n+n - n is the answer
2) n is the answer
3) n+m
4) 2n
