console.log(typeof 42);

console.log(typeof 'blubber');

console.log(typeof true);

console.log(typeof undeclaredVariable);
