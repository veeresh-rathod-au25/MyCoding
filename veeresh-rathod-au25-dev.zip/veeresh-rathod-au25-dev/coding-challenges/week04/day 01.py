A=[8,5,5,6,7,8]
print (tuple(A))

c=[]
a = int(input("Enter no of elements: "))
for i in range (a):
    a=int(input("Enter a number: "))
    c.append(a)
print(c)


A=[1,2,3,4,5,6,7,8,9]
A.pop(-4)
A[-2]="hello"
print(A)
