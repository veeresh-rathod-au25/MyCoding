a = float(input("Enter a no: "))
print(int(a))

a = 2.36
b = "Class"
c = 4
d = 0.2
print(type(a))
print(type(b))
print(type(c))
print(type(d))

a=7
b=7
c=a/b
print (c)

a=6
b=8
c=a*b
print (c)
