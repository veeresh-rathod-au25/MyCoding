a= int(input("Enter a number: "))
if (a%4==0):
  print("It is divisble")
else:
  print("Not divisible")

  a= int(input("Enter a number: "))
if (a%2==0):
  print("Even")
else:
  print("Odd")

a = 5
b = 7
c = a+b
(a!=c and c==12 or a+b==c)
print(True and False) 
print(True and True) 
