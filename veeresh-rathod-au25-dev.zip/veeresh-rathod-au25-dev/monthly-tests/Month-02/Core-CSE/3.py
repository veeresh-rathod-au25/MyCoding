l = list(map(int,input().split()))

n = l[0]
s = l[-1]

lis = [0] * n

sum_ = 0
for i in range((n + 1) // 2, n):
    lis[i] += 1
    sum_ += 1

while 1:
    if sum_ == s:
        break
    for i in range((n + 1) // 2 - 1, n):
        if sum_ < s:
            lis[i] += 1
            sum_ += 1

print (lis[(n + 1) // 2 - 1])