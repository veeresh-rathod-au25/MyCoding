def push(new_data):
    global head

    new_node